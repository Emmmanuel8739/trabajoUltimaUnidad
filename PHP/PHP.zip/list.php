<?php
// Mostrar todos los errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conectar a la base de datos
$mysqli = new mysqli("localhost", "root", "1234567890", "school");

// Verificar conexión
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Consultar la tabla student
$sql = "SELECT * FROM student";
$result = $mysqli->query($sql);

// Verificar si la consulta fue exitosa
if ($result === false) {
    die("Error: " . $mysqli->error);
}

// Generar la tabla HTML
$tableHtml = "<table border='1'><tr>";

// Obtener los nombres de las columnas
if ($result->num_rows > 0) {
    // Obtener los nombres de las columnas
    $fields = $result->fetch_fields();
    foreach ($fields as $field) {
        $tableHtml .= "<th>" . $field->name . "</th>";
    }
    $tableHtml .= "</tr>";

    // Obtener los datos de las filas
    while ($row = $result->fetch_assoc()) {
        $tableHtml .= "<tr>";
        foreach ($row as $k => $v) {
            $tableHtml .= "<td>" . htmlspecialchars($v) . "</td>";
        }
        $tableHtml .= "</tr>";
    }
} else {
    $tableHtml .= "<tr><td colspan='5'>No records found</td></tr>";
}

$tableHtml .= "</table>";

// Cerrar la conexión
$mysqli->close();

// Mostrar la tabla
echo $tableHtml;
?>
