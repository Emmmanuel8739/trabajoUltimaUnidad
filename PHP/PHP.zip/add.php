<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$nocontrol  = $_POST['nocontrol'];
$fullname  = $_POST['fullname'];
$career  = $_POST['career'];
$curp  = $_POST['curp'];
$currentgrade  = intval($_POST['currentgrade']);

$mysqli = new mysqli("localhost", "root", "1234567890", "school");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "INSERT INTO student (nocontrol, fullname, career, curp, currentgrade) VALUES(?,?,?,?,?)";

$statement = $mysqli->prepare($sql);
if($statement === false) {
    trigger_error('ERROR: ' . $mysqli->errno . ' ' . $mysqli->error, E_USER_ERROR);
}

//--- establecer los parametros
$statement->bind_param('ssssi', $nocontrol, $fullname, $career, $curp, $currentgrade);
$statement->execute();
$statement->close();
$mysqli->close();

echo "save successful";
echo "<a href='list.php'>List students</a>";
?>
