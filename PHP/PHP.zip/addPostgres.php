<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    // Validate and sanitize input
    $nocontrol = isset($_POST['nocontrol']) ? htmlspecialchars($_POST['nocontrol']) : '';
    $fullname = isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : '';
    $career = isset($_POST['career']) ? htmlspecialchars($_POST['career']) : '';
    $curp = isset($_POST['curp']) ? htmlspecialchars($_POST['curp']) : '';
    $currentgrade = isset($_POST['currentgrade']) ? intval($_POST['currentgrade']) : 0;

    // Check if all required fields are provided
    if (empty($nocontrol) || empty($fullname) || empty($career) || empty($curp) || $currentgrade <= 0) {
        die("Please fill in all fields.");
    }

    // Database connection
    $mysqli = new mysqli("localhost", "postgres", "1234567890", "tienda");
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Prepare and execute SQL statement
    $sql = "INSERT INTO student (nocontrol, fullname, career, curp, currentgrade) VALUES (?, ?, ?, ?, ?)";
    $statement = $mysqli->prepare($sql);
    if ($statement === false) {
        die("ERROR: Unable to prepare statement.");
    }
    $statement->bind_param('ssssi', $nocontrol, $fullname, $career, $curp, $currentgrade);
    if (!$statement->execute()) {
        die("ERROR: Unable to execute statement.");
    }

    // Close connection
    $mysqli->close();

    // Redirect user after successful insert
    header("Location: lisPostgres.php");
    exit();
?>

