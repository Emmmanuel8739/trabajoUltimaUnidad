<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    $dbconn = pg_connect("host=localhost dbname=school user=postgres password=1234567890")
        or die('Could not connect: ' . pg_last_error());

    $query = "SELECT * FROM student";
    $result = pg_query($dbconn, $query);

    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }

    if (pg_num_rows($result) > 0) {
        echo "<table border='1'>";
        // Encabezados de tabla
        echo "<tr>";
        $num_fields = pg_num_fields($result);
        for ($i = 0; $i < $num_fields; $i++) {
            echo "<th>" . pg_field_name($result, $i) . "</th>";
        }
        echo "</tr>";

        // Datos de la tabla
        while ($row = pg_fetch_assoc($result)) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . $value . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No data found";
    }

    pg_close($dbconn);
?>
