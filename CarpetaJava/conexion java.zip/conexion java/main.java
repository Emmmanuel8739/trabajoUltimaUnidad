public class Main {
 public static void main(String[] args) {
 Conexion conexion = new Conexion();
 conexion.listStudent();
 conexion.closeConnection();
 }
}